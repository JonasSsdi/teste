<?php

/* @var $this yii\web\View */
use yii\helpers\Html;
use yii\widgets\DetailView;

$this->title = 'Tetris';
?>
<div class="site-index">

    <div class="jumbotron">
        <?= Html::img('/@img/icomp.png') ?>
        
        
        <p><?= Html::a('Jogar!!', ['/jogada'], ['class' => 'btn btn-success']) ?></p>
    </div>

    
</div>

