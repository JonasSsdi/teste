(function () {

    var tabuleiro;
    var peca;
    var pecaProx;
    var fps = 10;
    var tabela;
    var tabela1;
    var tabelaAux;
    var linha;
    var cont;
    var ladoE=0;
    var gameLoop;
    var salvos;
    var baixo;
    var lados;
    var texto2;
    var peca_aux;
    var pontos=0;


    addEventListener("keydown", function(e) {
        if (e.key == "ArrowLeft") {

                    moveEsquerda();
                



         }else { if (e.key == "ArrowRight") {

                        moveDireita();
                    }
                }
            
        

    });

    function init () {
        createProximaPeca();
        createInfo();
        createTab();
        start();
    }

    function start(){
            createPeca(Math.floor(Math.random() * 6));
            proxima();
            gameLoop = setInterval(run, 5000/fps);
    }

    function run () {
            
             moveBaixo();
             
       
    }



    

    function createTab () {
        tabuleiro = document.querySelector("#tabuleiro");
        tabela = document.createElement("table");
        tabela.id="tab";
        linha = document.createElement("tr");
        cont = document.createElement("td");
        tabuleiro.appendChild(tabela);
            for(var i=0;i<10;i++){
            tabela.appendChild(linha);
            for(var j=0;j<10;j++){
                linha.appendChild(cont);
                cont = document.createElement("td");

            }
            linha = document.createElement("tr");

        }
        
    }

     function createTabAux () {
        tabelaAux = document.createElement("table");
        tabela.id="tab";
        linha = document.createElement("tr");
        cont = document.createElement("td");
        tabuleiro.appendChild(tabela);
            for(var i=0;i<10;i++){
            tabela.appendChild(linha);
            for(var j=0;j<10;j++){
                linha.appendChild(cont);
                cont = document.createElement("td");

            }
            linha = document.createElement("tr");

        }
        
    }


    function createProximaPeca () {
        tabuleiro = document.querySelector("#proxima-peca");
        tabela1 = document.createElement("table");
        linha1 = document.createElement("tr");
        cont1 = document.createElement("td");
        tabuleiro.appendChild(tabela1);
        for(var i=0;i<4;i++){
            tabela1.appendChild(linha1);
            for(var j=0;j<4;j++){
                linha1.appendChild(cont1);
                cont1 = document.createElement("td");

            }
            linha1 = document.createElement("tr");

        }

    }
    function proxima(){
        limpa2();
        for(var i=0; i<pecaProx.length ;i++){
            tabela1.rows[pecaProx[i][0]].cells[pecaProx[i][1]].style.backgroundColor="black";
        }

    }

    function createInfo () {
        tabuleiro = document.querySelector("#informacoes");
        info = document.createElement("h1");
        texto = document.createTextNode("Pontuação :");
        texto2= document.createElement("text");
        info.appendChild(texto);
        info.appendChild(texto2);
        tabuleiro.appendChild(info);

    }

    function createPeca (x){




        switch(x){

            case 0:

                    pecaProx=[[0,1],[1,1],[2,1],[3,1]];

                    break;

            case 1:

                    pecaProx=[[1,0],[1,1],[1,2],[1,3]];
                    break;

            case 2:

                    pecaProx=[[1,0],[1,1],[1,2],[2,1]];
                    break;

            case 3:

                    pecaProx=[[0,1],[1,1],[2,1],[2,2]];
                    break;

            case 4:

                    pecaProx=[[1,0],[1,1],[0,1],[0,2]];
                    break;


            case 5:

                    pecaProx=[[1,2],[1,1],[2,1],[2,2]];
                    break;


        }

        count=0; 
        peca=pecaProx;
        console.log("criou!!  count = " + count);
        pinta(peca);



    }

    function pontoLinha(){

    	var count_col=0;

        for(var i=0;i<10;i++){

            for(var j=0;j<10;j++){

            	if(tabela.rows[i].cells[j].style.backgroundColor=="blue"){
            		count_col++;
            	}


            }
            if(count_col==10){
            	atualiza_ponto(i);
            	return null;
            }
            count_col=0;


        }

    }

    function atualiza_ponto(l){


    	 for(var i=l;i>0;i--){

            for(var j=0;j<10;j++){

            	tabela.rows[i].cells[j].style.backgroundColor=tabela.rows[i-1].cells[j].style.backgroundColor



            }

        }



    }

    function pinta(peca){

    	    tabela.rows[peca[0][0]].cells[peca[0][1]].style.backgroundColor="black";
            tabela.rows[peca[1][0]].cells[peca[1][1]].style.backgroundColor="black";
            tabela.rows[peca[2][0]].cells[peca[2][1]].style.backgroundColor="black";
            tabela.rows[peca[3][0]].cells[peca[3][1]].style.backgroundColor="black";



    }

    function roda(x){
        var lin=0;
        var col=5;

                for(i=0; i<4; i++){
            

                if(peca[i][1]+1>=10 ){
                    return null;

                }else{
                    if(tabela.rows[peca[i][0]].cells[peca[i][1]+1].style.backgroundColor=="blue"){
                    return null;
                    }
                }
            
            }


           switch(x){

           



    }
        
    }

    function limpa(){
        for(var i=0;i<10;i++){
            for(var j=0;j<10;j++){
                for(var k=0;k<peca.length;k++){
                        if(tabela.rows[i].cells[j].style.backgroundColor!="blue"){
                        tabela.rows[i].cells[j].style.backgroundColor="lightyellow";
                    }
                    
                }

            }

        }

    }

  function limpa1(){
        for(var i=0;i<peca.length;i++){

                     tabela.rows[peca[i][0]].cells[peca[i][1]].style.backgroundColor="blue";
                 
                    

        }

        

    }

    function limpa2(){
        for(var i=0;i<4;i++){
            for(var j=0;j<4;j++){
 
                    
                        tabela1.rows[i].cells[j].style.backgroundColor="blue";
                    
                

            }

        }

    }

    function moveEsquerda(){
        var aux=peca;
        var i=0;
        var limi=0;

        limpa();
            for(i=0; i<4; i++){
            

                if(peca[i][1]-1==10 ){
                    return null;

                }else{
                    if(tabela.rows[peca[i][0]].cells[peca[i][1]-1].style.backgroundColor=="blue"){
                    return null;
                    }
                }
            
            }

            
            tabela.rows[peca[0][0]].cells[peca[0][1]-1].style.backgroundColor="black";
            tabela.rows[peca[1][0]].cells[peca[1][1]-1].style.backgroundColor="black";
            tabela.rows[peca[2][0]].cells[peca[2][1]-1].style.backgroundColor="black";
            tabela.rows[peca[3][0]].cells[peca[3][1]-1].style.backgroundColor="black";
            peca[0][1]=peca[0][1]-1;
            peca[1][1]=peca[1][1]-1;
            peca[2][1]=peca[2][1]-1;
            peca[3][1]=peca[3][1]-1;
    }

     function moveDireita(){
        var limi=0;
        var i=0;
       
            limpa();

            for(i=0; i<peca.length; i++){
            

                if(peca[i][1]+1==10 ){
                    return null;

                }else{
                    if(tabela.rows[peca[i][0]].cells[peca[i][1]+1].style.backgroundColor=="blue"){
                    return null;
                    }
                }
            
            }


            tabela.rows[peca[0][0]].cells[peca[0][1]+1].style.backgroundColor="black";
            tabela.rows[peca[1][0]].cells[peca[1][1]+1].style.backgroundColor="black";
            tabela.rows[peca[2][0]].cells[peca[2][1]+1].style.backgroundColor="black";
            tabela.rows[peca[3][0]].cells[peca[3][1]+1].style.backgroundColor="black";
            peca[0][1]=peca[0][1]+1;
            peca[1][1]=peca[1][1]+1;
            peca[2][1]=peca[2][1]+1;
            peca[3][1]=peca[3][1]+1;

    }

        function moveBaixo(){
        var aux=peca;
        var i;
        var j;
        var limi= 0;
        var limi2= 0;
        limpa();
        for(i=0; i<peca.length; i++){
            

                if(peca[i][0]+1>=10 ){
                    clearInterval(gameLoop);
                    limpa1();
                    start();

                }else{

                    if(tabela.rows[peca[i][0]+1].cells[peca[i][1]].style.backgroundColor=="blue"){
                    	if(count==0){
                    		   clearInterval(gameLoop);
                    		   alert("voce perdeu!!");
                        }else{

                               clearInterval(gameLoop);
                               limpa1();
                               start();
                 }
                }
               }
            
        } 
             
  
            tabela.rows[peca[0][0]+1].cells[peca[0][1]].style.backgroundColor="black";
            tabela.rows[peca[1][0]+1].cells[peca[1][1]].style.backgroundColor="black";
            tabela.rows[peca[2][0]+1].cells[peca[2][1]].style.backgroundColor="black";
            tabela.rows[peca[3][0]+1].cells[peca[3][1]].style.backgroundColor="black";
            peca[0][0]=peca[0][0]+1;
            peca[1][0]=peca[1][0]+1;
            peca[2][0]=peca[2][0]+1;
            peca[3][0]=peca[3][0]+1;
            count++;
            pontos++;
            texto2.value=pontos.toString();
            pontoLinha();
            //} 
            
        
        

    }


    init();
})();
