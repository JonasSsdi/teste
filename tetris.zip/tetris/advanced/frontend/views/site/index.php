<?php

/* @var $this yii\web\View */
use yii\helpers\Html;

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Congratulations!</h1>

        <p class="lead">You have successfully created your Yii-powered application.</p>
        <?= Html::img('@web/icomp.png',['width'=>'400']) ?>



        <p><?= Html::a('iniciar Jogo', ['jogada/play'],['class' => 'btn btn-success']) ?></p>
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">

            </div>
        </div>

    </div>
</div>
