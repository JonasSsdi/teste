<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel common\models\JogadaSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
$this->registerCssFile('@web/css/estilos.css');
$this->registerJsFile('@web/js/tetris.js', [
'position' => $this::POS_END
]);
$this->title = 'Jogadas';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="jogada-index">


    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <div id="proxima-peca"></div>

    <div id="tabuleiro"></div>

    <div id="informacoes"></div>

</div>
